public interface Measurable {
    double getArea();
}
